if (document.domain != "ubc.ca") {

/* This script is used to present the footer on HTML or JSP pages (not supported by ColdFusion)
Last updated: 24 April 2001 */

// For easy changes between servers
baseMail = "student.information@ubc.ca"; //NOSONAR Global Variable
// if (document.URL.indexOf("ssc.adm.ubc.ca") != -1) {
	supportMail = "sswebsupport@exchange.ubc.ca"; //NOSONAR Global Variable
	recordsMail = "SSWebSupport@exchange.ubc.ca"; //NOSONAR Global Variable
//}

// Automatic javascript record of document updates
generateDate = new Date(); //NOSONAR Global Variable
document.write('</td></tr><tr><td><br>');
document.write('<p align="center" class="min">');
document.write('For questions about UBC, including registration, check out <a href="http://askme.ubc.ca">Ask Me @ UBC</a> for immediate answers to your questions.<br />');
document.write('Please send any technical questions or site comments to <a href="mailto:' + supportMail + '?subject=Referral%20page%20' + document.URL +'">' + supportMail + '</a>.<br />');
document.write('Last updated ' + document.lastModified + ' PST. Information on this page is subject to change.<br />');
document.write('Copyright &copy; 1999-2009 <a href="http://www.ubc.ca/">The University of British Columbia</a>.</p>');
document.write('</td></tr></table>');

}